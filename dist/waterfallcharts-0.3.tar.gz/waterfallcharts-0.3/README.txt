!! This is a work in progress package !!

Waterfall_charts attempts to provide an easy and quick way to plot basic (for now) and more advanced (to come) waterfall charts of the accounting and finance type.